package com.example.myapplication;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

public class StyleProcess extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_style_process);
        SampleAdapter adapter = new SampleAdapter(getSupportFragmentManager());
        adapter.addFragment(new SelectImageFragment(), "Select Image");
        adapter.addFragment(new SelectStyleFragment(), "Select Style");
        adapter.addFragment(new ShowResultFragment(), "Result");
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(adapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);

    }
}